<!-- <p align="center">
  <img src="latex-talk.svg" alt="latex-talk" width=75%>
</p> -->

# 现代 LaTeX 从入门到入门

## PDF 下载：

- [阅读版](https://git.nju.edu.cn/atXYblip/latex-lecture/uploads/ce319e363123f7db882e1408fe352155/lecture-handout-20220312.pdf)
- [放映版](https://git.nju.edu.cn/atXYblip/latex-lecture/uploads/23dc1d18ef8b259b46df120a4e5214c4/lecture-display-20220312.pdf)

-----

Copyright (C) 2022 by Yu Xiong.
