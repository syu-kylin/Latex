if [ "$1" == "-c" ]
then
    latexmk -c
else
    latexmk -pdflua
fi
