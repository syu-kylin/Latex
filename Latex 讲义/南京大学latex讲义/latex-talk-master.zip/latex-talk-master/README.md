# 《LaTeX 入门》 南方科技大学图书馆培训讲座

[预览PDF(点此)](./main.pdf)

## 致谢

* [Tonanguyxiro](https://github.com/Tonanguyxiro) 提供 [Beamer 模版](https://github.com/Tonanguyxiro/SUSTech-Slide-Template)
* [SUSTech-CRA](https://github.com/SUSTech-CRA) 提供资源支持
* [南方科技大学图书馆](https://lib.sustech.edu.cn/) 提供场地支持
