数学模式是 LaTeX 相对于其他排版系统的优势，关于它的文档和提及的问题也是相当的多。

「The LaTeX Mathematics Companion」是杜克大学的 Helin Gai 编写的，以入门文档的形式介绍了 LaTeX 的数学模式。「Math Mode」是 Herbert Voß 编写的注明文档，大多数关于数学模式的疑问都能在这里找到解决方法。「The Comprehensive LaTeX Symbol List」是一份关于符号的文档，介绍了数以千计的符号在 LaTeX 中如何输出，当你需要输出符号却不知何往时，打开它查阅是很好的选择。「ChinaTeXMathFAQ」是 ChinaTeX 管理员王昭礼和马起园 (Clerk Ma) 共同编写的关于数学的常见问题集，非常精美。

Liam Huang
2014-11-21
