「LaTeX2e 插图指南」是 Keith Reckdahl 编写的「Using Import graphics in LaTeX2e」的中译版，翻译工作由王磊负责。这份资料详尽地介绍了关于插图的通常需求，是十分优秀的资料。

关于表格，我尚未发现优秀的资料，附上我写的一篇关于 LaTeX 表格的博客：
<http://liam0205.me/2013/08/04/LaTeX-table/>

Liam Huang
2014-11-20
