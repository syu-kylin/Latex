
NOTE ON FONT SAMPLE SOURCES

These font sample files call the following additional files as inputs:

abstract.tex
acknowledgments.tex
appendixa.tex
biography.tex
chapter1.tex
mitthesis-sample.bib
mydesign.tex

All of those files are in the directory mitthesis/MIT-thesis-template.
