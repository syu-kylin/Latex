@echo off"
set GIT_SSH_COMMAND=ssh -i "%USERPROFILE%\.ssh\MatebookGit_rsa"
git add .
git commit -am "Autosave %date%-%time:~0,8%"
git push