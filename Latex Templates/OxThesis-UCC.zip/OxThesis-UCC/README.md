# OxThesis-UCC

**OxThesis-UCC** is a LaTeX template based on an Oxford University thesis, originally published on [the Oxford Echoes blog](https://www.oxfordechoes.com/oxford-thesis-template/), and have been adopted to University College Cork thesis.

------

Some of the features of **OxThesis** are:

*Fantastic chapter pages.* The template retains Sam Evans’s use of the [quotchap](https://www.ctan.org/pkg/quotchap?lang=en) and [minitoc](https://www.ctan.org/pkg/minitoc?lang=en) packages to (optionally) include an epigraph and brief table of contents at the beginning of each chapter. I found this a great way to inject a bit of personality into the thesis (via the epigraph) and ensure that my reader wasn’t getting lost (table of contents). My modifications cleaned up some of the spacing, ensuring single-spaced tables and slightly more compact chapter headings.

*Table of Contents refinements.* Careful attention was paid to spacing and page headings in the table of contents as well as other heading sections. This can get tricky in documents using lots of packages. This template also inserts an “Appendices” page (and ToC entry) between chapters and appendices.

*Table of abbreviations.* Many science and engineering theses use lots of abbreviations. Humanities and social sciences theses often need glossaries. While there are some dedicated LaTeX classes that meet these needs in complex cases, I decided to create a simple list environment to handle the routine cases.

*Highlighted corrections.* Most Oxford theses go through a round of corrections, as time-honored a tradition as the viva itself. Minor corrections generally just involve sending a PDF of your revised thesis to your internal examiner. (Major corrections often require a more exacting process.) This class allows you to designate text (or figures, etc) as a correction. You can then toggle between generating a document in which these corrections are highlighted in blue (ideal for sending to your examiner for a quick read-through) and just printing them without any adornment (for generating your final copy).

*Page layout, draft, and spacing options.* In a few keystrokes, you can switch between a double-spaced, single-sided, binding-margin document (ideal for submission), a 1.5-spaced, double-sided document (for your parents’ copy), or a version with equal left and right margins (for submitting as a PDF). An optional draft notice (with date) can be included in the footer — just remember to turn it off before submitting!

*Master’s thesis title page.* Some masters’ degrees require title pages with a candidate number and word count rather than a name and college, to ensure anonymity for the examinees. They also require a statement of authenticity / originality on the title page. This template has a quick option to switch to this master’s submission format. And, just as importantly, it can be turned off when you want to print a version for yourself.

---
Full details with pictures can still be found at the [Oxford Echoes blog post](https://www.oxfordechoes.com/oxford-thesis-template/).  Feel free to submit push requests or issues.

---


> Originally written with [StackEdit](https://stackedit.io/).
